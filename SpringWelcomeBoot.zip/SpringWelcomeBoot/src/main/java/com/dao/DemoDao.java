package com.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.bean.Employee;

@Repository
public class DemoDao {
	@Autowired
	SessionFactory sessionFactory;
	public Map<Integer, Employee> getEmpFromDao(){

		Map<Integer, Employee> map=new HashMap<Integer, Employee>();
		map.put(1, new Employee(101, "Sunitha"));
		map.put(2, new Employee(101, "BinduRaj"));
		map.put(3, new Employee(101, "Aswathy"));
		return map;
	}
	
	public List<Employee> getFromdb(){
		
		Session session=sessionFactory.openSession();
		Query qry= session.createQuery("select e from Employee e");
		//Query query=session.createQuery("select e from Employee e");
		List<Employee> emList=qry.list();
		return emList;
		
	}
	
	public Employee getEmpById(int id){
		Session session=sessionFactory.openSession();
		/*Query query=session.createQuery("select e from Employee e where e.id=?");
		query.setParameter(0, new Integer(id));
		List<Employee> employee=query.list();
		Employee emp=employee.get(0);*/
		
		Employee emp=session.get(Employee.class, new Integer(id));
		
		return emp;
	}
	
	public Employee updateEmpById(int id,String name){
		Session session=sessionFactory.openSession();
		Employee emp=session.get(Employee.class, new Integer(id));
		Transaction transaction=session.getTransaction();
		if(emp!=null){
			emp.setName(name);
			transaction.begin();
			session.update(emp);
			transaction.commit();
			System.out.println("Record updated successfully");
		}else{
			System.out.println("Record not found");
		}
		
		return emp;
	}
	
}
