package com.main;

import org.hibernate.SessionFactory;
import org.hibernate.jpa.HibernateEntityManagerFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.annotation.Bean;
//@configuration + component scan
@SpringBootApplication(scanBasePackages="com")
@EntityScan(basePackages="com.bean")
public class DemoTest {
	@Bean
	public SessionFactory sessionFactory(HibernateEntityManagerFactory hem){
		return hem.getSessionFactory();
	}

	public static void main(String[] args) {
		/*stand alone application*/
		/*SpringApplication.run(DemoTest.class, args);
		AnnotationConfigApplicationContext obj=new AnnotationConfigApplicationContext();
		obj.scan("com");
		obj.refresh();
		Employee emp=(Employee) obj.getBean("employee");
		emp.setId(100);
		emp.setName("arathi");
		System.out.println(emp.getId()+"  "+emp.getName());*/
		/*stand alone application*/
		SpringApplication.run(DemoTest.class, args);

	}

}
