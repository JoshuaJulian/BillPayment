package com.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bean.Employee;
import com.dao.DemoDao;

@Service
public class DemoService {
	@Autowired
	DemoDao demoDao;
	
	public Map<Integer, Employee> getListEmployees(){
			
			
			Map<Integer, Employee> map=new HashMap<Integer, Employee>();
			map.put(1, new Employee(101, "arathi"));
			map.put(2, new Employee(101, "Arathi Raj"));
			map.put(3, new Employee(101, "Arathi Raj M"));
			return map;
			
		}

	public Map<Integer, Employee> getEmpFromDao(){
		
		return demoDao.getEmpFromDao();
		
	}
	
	public List<Employee> getFromdb(){
		return demoDao.getFromdb();
	}
	
	public Employee getEmpById(int id){
		return demoDao.getEmpById(id);
	}
	
	public Employee updateEmpById(int id,String name){
		return demoDao.updateEmpById(id, name);
	}

}
