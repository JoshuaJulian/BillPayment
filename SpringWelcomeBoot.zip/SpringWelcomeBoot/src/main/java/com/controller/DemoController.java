package com.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.bean.Employee;

@Controller
public class DemoController {
	
	@RequestMapping(value="/say")
	@ResponseBody
	public String sayHello(){
		System.out.println("I came here");
		return "Welcome to spring boot with MVC";
	}
	@RequestMapping(value="/emp")
	@ResponseBody
	public Employee getEmployee(){
		Employee emp=new Employee();
		emp.setId(100);
		emp.setName("arathi");
		return emp;
	}
	@RequestMapping(value="/emps")
	@ResponseBody
	public List<Employee> getListEmployees(){
		
		/*Employee emp=new Employee();
		List<Employee> list=new ArrayList<Employee>();
		emp.setId(1);
		emp.setName("arathi");
		list.add(emp);
		emp.setId(2);
		emp.setName("athira");
		list.add(emp);
		emp.setId(3);
		emp.setName("anu");
		list.add(emp);
		return list;*/
		List<Employee> list=new ArrayList<Employee>();
		list.add(new Employee(100, "arathi"));
		list.add(new Employee(101, "athiera"));
		list.add(new Employee(102, "anu"));
		return list;
		
	}
	

}
