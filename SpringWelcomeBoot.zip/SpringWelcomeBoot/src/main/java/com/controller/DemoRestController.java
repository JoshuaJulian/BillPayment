package com.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bean.Employee;
import com.service.DemoService;

@RestController
public class DemoRestController {
	@Autowired
	DemoService demoService;
	
	@RequestMapping(value="/empss")
	public List<Employee> getListEmployees(){
		
		List<Employee> list=new ArrayList<Employee>();
		list.add(new Employee(100, "arathi"));
		list.add(new Employee(101, "athiera"));
		list.add(new Employee(102, "anju"));
		return list;
		
	}
	
	@RequestMapping(value="/empFromSrvc")
	public Map<Integer, Employee> getFromServcie(){
		
		return demoService.getListEmployees();
		
	}
	
	@RequestMapping(value="/empFromdao")
	public Map<Integer, Employee> getFromDao(){
		
		return demoService.getEmpFromDao();
		
	}
	
	@RequestMapping(value="/getfromdb")
	public List<Employee> getFromdb(){
		System.out.println("inside controller......");
		return demoService.getFromdb();
	}
	
	@RequestMapping(value="/getEmpById/{id}")
	public Employee getEmployeeById(@PathVariable("id") int id){
		return demoService.getEmpById(id);
	}
	
	@RequestMapping(value="/updateEmpById/{id}/{name}")
	public Employee updateEmployeeById(@PathVariable("id") int id,@PathVariable("name") String name){
		return demoService.updateEmpById(id, name);
	}

}
